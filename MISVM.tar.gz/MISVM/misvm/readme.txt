This package includes the MATLAB codes of MIMLfast, which is a fast algorithm for multi-instance multi-label learning.

We have included a sample data in the package. To get start with the codes, please run example.m in MATLAB. 

For the detail, please refer to our paper:
S.-J. Huang W. Gao and Z.-H. Zhou. Fast multi-instance multi-label learning. In: Proceedings of the 28th AAAI Conference on Artificial Intelligence (AAAI'14), 2014.